"""Constants for sac_log."""
# Log configurations
SACLOG = "SACLOG"
LOG_HANDLER = "log_handler"
LOG_LEVEL = "log_level"
LOG_FORMATTER = "log_formatter"
LOG_FILE_PATH = "log_file_path"
LOG_FILENAME = "log_filename"
LOG_BACKUP_COUNT = "log_backup_count"
LOG_ROTATION_WHEN = "log_rotation_when"
LOG_UTC_STATUS = "log_utc_status"
LOG_MAX_BYTES = "log_max_bytes"
# Handler classes
STREAM_HANDLER = "StreamHandler"
FILE_HANDLER = "FileHandler"
ROTATING_FILE_HANDLER = "RotatingFileHandler"
TIMED_ROTATING_FILE_HANDLER = "TimedRotatingFileHandler"
# Configuration filename
DEFAULT_CONFG_FILENAME = "saclog.cfg"
# Field names
FILENAME = "filename"
MAXBYTES = "maxBytes"
BACKUPCOUNT = "backupCount"
WHEN = "when"
UTC = "utc"


# Messages
ERROR_MSG = "[ERROR]: {msg}"
CREATE_LOGDIR_ERROR = "Error occured while creating `{path}`. Error: {err}. {exp}"
LOG_ERROR = "The path `{path}` does not exists or is not writable."
