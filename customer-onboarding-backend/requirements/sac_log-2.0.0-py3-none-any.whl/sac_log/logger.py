"""Create logger object and attach handlers to it.

This allows to add logging to FileHandler, StreamHandler, RotatingFileHandler, TimedRotatingFileHandler

Logging can be with single handler or multiple handlers.
"""

import logging
import os
from logging import FileHandler, Formatter, Logger, StreamHandler
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from typing import Any, Dict, List

from sac_log.constants import (BACKUPCOUNT, CREATE_LOGDIR_ERROR,
                               DEFAULT_CONFG_FILENAME, ERROR_MSG, FILE_HANDLER,
                               FILENAME, LOG_BACKUP_COUNT, LOG_ERROR,
                               LOG_FILE_PATH, LOG_FILENAME, LOG_FORMATTER,
                               LOG_HANDLER, LOG_LEVEL, LOG_MAX_BYTES,
                               LOG_ROTATION_WHEN, LOG_UTC_STATUS, MAXBYTES,
                               ROTATING_FILE_HANDLER, SACLOG, STREAM_HANDLER,
                               TIMED_ROTATING_FILE_HANDLER, UTC, WHEN)
from sac_log.exceptions import LoggingError
from sac_log.utils import (get_configurations, is_multiple_handlers, is_true,
                           touch)


def get_handler_dict() -> Dict[str, Any]:
    """Get handler dictionary with the list of parameters required for the handler.

    :return: Dictionary containing the list of fields required for the handler object
    :rtype: Dict[str, Any]
    """
    return {
        STREAM_HANDLER: [],
        FILE_HANDLER: [LOG_FILENAME],
        ROTATING_FILE_HANDLER: [LOG_FILENAME, LOG_MAX_BYTES, LOG_BACKUP_COUNT],
        TIMED_ROTATING_FILE_HANDLER: [LOG_FILENAME, LOG_ROTATION_WHEN, LOG_BACKUP_COUNT, LOG_UTC_STATUS]
    }


def get_handler(handler: str) -> Any:
    """Get handler from list of available handlers. default is StreamHandler.

    :param handler: Handler name whose object is to be created
    :type handler: str
    :return: handler object requestes, default streamhandler
    :rtype: Any
    """
    handlers_dict = {
        STREAM_HANDLER: StreamHandler,
        FILE_HANDLER: FileHandler,
        ROTATING_FILE_HANDLER: RotatingFileHandler,
        TIMED_ROTATING_FILE_HANDLER: TimedRotatingFileHandler
    }

    return handlers_dict.get(handler, StreamHandler)


def get_parameters(handler_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Get parameters required for the handler object creation.

    :param handler_name: Handler name for which to get parameters
    :type handler_name: str
    :param config: dictoinary conatining values setup in configurations
    :type config: Dict[str, Any]
    :return: Dictionary containing the fields required for the congured log handler
    :rtype: Dict[str, Any]
    """
    parameters: Dict[str, Any] = {}
    mapper: Dict[str, Any] = {
        LOG_FILENAME: FILENAME,
        LOG_MAX_BYTES: MAXBYTES,
        LOG_BACKUP_COUNT: BACKUPCOUNT,
        LOG_ROTATION_WHEN: WHEN,
        LOG_UTC_STATUS: UTC
    }
    handlers_dict: Dict[str, Any] = get_handler_dict()
    handler_fields: Any = handlers_dict.get(handler_name, [])
    for item in handler_fields:
        if item in [LOG_BACKUP_COUNT, LOG_MAX_BYTES]:
            parameters[mapper[item]] = int(config[item])
        elif LOG_FILENAME == item:
            parameters[mapper[item]] = os.path.join(config[LOG_FILE_PATH], config[item])
        elif LOG_UTC_STATUS == item:
            parameters[mapper[item]] = is_true(config[item])
        else:
            parameters[mapper[item]] = config[item]

    return parameters


def check_required(handler_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Check whether config has all the required fields in it, if not set those key value pairs.

    :param handler_name: Name of the handler
    :type handler_name: str
    :param config: Dictionary containing all the configurations read from the config file
    :type config: Dict[str, Any]
    :return: Updated configurations
    :rtype: Dict[str, Any]
    """
    handlers_dict: Dict[str, Any] = get_handler_dict()

    filepath: str = os.path.join(os.path.dirname(__file__), DEFAULT_CONFG_FILENAME)

    config_list: Any = handlers_dict.get(handler_name, [])
    config_parser: Dict[str, Any] = get_configurations(filepath)
    log_config: Dict[str, Any] = config_parser[SACLOG.upper()]

    for item in config_list:
        if item not in config:
            config[item] = log_config[item]

    return config


def touch_log_path(log_file_path: str) -> None:
    """Touch Log file path to verify whether it exists or not, and if not can it be created.

    :param log_file_path: Path of the log file
    :type log_file_path: str
    :raises LoggingError: If the permission error is thrown while creating the log directory or file.
    :raises LoggingError: Log file creation permission is not available.
    """
    status = True
    try:
        status = touch(log_file_path)
    except PermissionError as err:
        msg = CREATE_LOGDIR_ERROR.format(path=log_file_path, err=str(err), exp=LOG_ERROR.format(path=log_file_path))
        raise LoggingError(ERROR_MSG.format(msg=msg)) from err
    else:
        if not status:
            msg = LOG_ERROR.format(path=log_file_path)
            raise LoggingError(ERROR_MSG.format(msg=msg))


def configure_logger(handler_name: str, formatter: Formatter, config: Dict[str, Any], logger: Logger) -> None:
    """Configure Logger with level, formater and attach log handler.

    :param handler_name: Name of the handler
    :type handler_name: str
    :param formatter: Formatter object for logger
    :type formatter: Formatter
    :param config:Log configuration dictionary
    :type config: Dict[str, Any]
    :param logger: Logger object to attach logging handler details
    :type logger: Logger
    :raises LoggingError: If the log file path is not writable.
    """
    # Check required fields
    config = check_required(handler_name, config)
    # Touch the path
    touch_log_path(config[LOG_FILE_PATH])
    # get the handler name
    handler_obj: Any = get_handler(handler_name)
    # Assign the values to the required parameters
    parameters: Dict[str, Any] = get_parameters(handler_name, config)
    # Generate handler object
    handler: Any = handler_obj(**parameters)
    # Set level for the handler
    handler.setLevel(config[LOG_LEVEL])
    # Set formatter for the handler
    handler.setFormatter(formatter)
    # Add handler to logger
    logger.addHandler(handler)


def get_logger(name: str, config: Dict[str, Any]) -> Logger:
    """Get logger object to enable logging.

    :param name: Log file path
    :type name: str
    :param config: configurations dictionary containing
    :type config: Dict[str, Any]
    :return: Logger object
    :rtype: Logger
    """
    # Create a logger object
    logger: Logger = logging.getLogger(name)
    logger.setLevel(config[LOG_LEVEL])

    formatter: Formatter = Formatter(config[LOG_FORMATTER])

    if is_multiple_handlers(config[LOG_HANDLER]):
        handlers_list: List[str] = str(config[LOG_HANDLER]).split(',')
        for handler_name in handlers_list:
            configure_logger(handler_name, formatter, config, logger)
    else:
        configure_logger(config[LOG_HANDLER], formatter, config, logger)

    return logger
