"""Base configurations error exception.

Can be inherited for more specific exceptions.
"""


class ConfigurationsError(LookupError):
    """Exception to be raised when required configurations are missing.

    :param LookupError: Inherits Lookup Error
    :type LookupError: class
    """

    def __init__(self, category: str, message: str) -> None:
        """Initialise configurations error.

        :param category: Category of the error
        :type category: str
        :param message: Error message
        :type message: str
        """
        super().__init__()
        self.category = category
        self.message = message

    def __str__(self) -> str:
        """Represent error as string.

        :return: Configurations error when called by str function
        :rtype: str
        """
        return f"{self.__class__.__name__} [{self.category}]: {self.message}"

    def __repr__(self) -> str:
        """Raw object representation of the Error.

        :return: Raw representation of the configurations error.
        :rtype: str
        """
        error = "<{name} category={cat} msg={msg}>"
        return error.format(
            name=self.__class__.__name__, cat=self.category, msg=self.message
        )
