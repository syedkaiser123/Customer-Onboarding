"""Exceptions used to handle errors related to Schema processing."""
from sac_configurations.exceptions.base import ConfigurationsError


class SchemaConfigsError(ConfigurationsError):
    """Exception to be raised when required configurations are missing.

    :param ValueError: Inherits Lookup Error
    :type ValueError: class
    """

    def __init__(self, category: str, message: str) -> None:
        """Initialise Schema configurations error.

        :param category: Error category
        :type category: str
        :param message: Error message
        :type message: str
        """
        super().__init__(category, message)
        self.category = category
        self.message = message
