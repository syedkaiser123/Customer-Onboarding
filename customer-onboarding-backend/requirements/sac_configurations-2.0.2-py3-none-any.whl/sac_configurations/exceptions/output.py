"""Exceptions used during handling output data."""
from sac_configurations.exceptions.base import ConfigurationsError


class OutputConfigsError(ConfigurationsError):
    """Exception to be raised while writing to the output.

    :param LookupError: Inherits Value error
    :type LookupError: class
    """

    def __init__(self, category: str, message: str) -> None:
        """Initialise output configurations error.

        :param category: Category of the error
        :type category: str
        :param message: Error message
        :type message: str
        """
        super().__init__(category, message)
        self.category = category
        self.message = message
