"""Input configurations of type cfg/conf."""
from configparser import ConfigParser
from configparser import DuplicateOptionError
from configparser import DuplicateSectionError
from typing import Any
from typing import Dict
from typing import List

from sac_configurations.constants.chars import PERCENT_STR
from sac_configurations.constants.general import DEFAULT
from sac_configurations.exceptions.base import ConfigurationsError
from sac_configurations.input.base import InputConfig
from sac_configurations.utils.converters import convert_to_bool
from sac_configurations.utils.converters import convert_to_number
from sac_configurations.utils.validators import is_bool
from sac_configurations.utils.validators import is_int
from sac_configurations.utils.validators import is_none
from sac_configurations.utils.validators import is_number


class CFGConfig(InputConfig):
    """CFG configurations class to read cfg / conf / ini files.

    :param BaseInputConfig: Inherits Base Configurations class.
    :type BaseInputConfig: class
    """

    def read(self, filenames: List) -> None:
        """Read list of files provided and load in configurations.

        :param filenames: List of filenames
        :type filenames: List
        :raises ConfigurationsError: If duplicate section found
            in the same configurations file
        :raises ConfigurationsError: if duplicate option found
            in the same section
        """
        config: ConfigParser = ConfigParser()
        try:
            if config.read(filenames=filenames):
                self.config: ConfigParser = config
        except DuplicateSectionError as err:
            category = DuplicateSectionError.__name__
            message = err.message
            raise ConfigurationsError(category, message) from err
        except DuplicateOptionError as err:
            category = DuplicateOptionError.__name__
            message = err.message
            raise ConfigurationsError(category, message) from err

    def sections(self) -> List[str]:
        """Get a list of section names from the configurations.

        :return: List of section names.
        :rtype: List[str]
        """
        return self.config.sections()

    def flatten(self) -> None:
        """Flatten the configurations into only one section."""
        self.flattened: ConfigParser = ConfigParser()
        self.flattened.add_section(DEFAULT)
        for section in self.config.sections():
            for key, value in self.config.items(section):
                key = (
                    f"{section.lower()}_{key.lower()}"
                    if DEFAULT != section.lower()
                    else key.lower()
                )
                if PERCENT_STR in value:
                    # Escape the `%` symbols if exists.
                    escape = f"{PERCENT_STR}{PERCENT_STR}"
                    value = value.replace(PERCENT_STR, escape)
                self.flattened.set(DEFAULT, key, value)

    def get(self, section: str, to_flat: bool = False) -> Dict[str, Any]:
        """Get configurations specified in a section.

        :param section: Configurations section
        :type section: str
        :param to_flat: Flag indicating whether to read from
            flattened configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations dictionary
        :rtype: Dict[str, Any]
        """
        config: Dict[str, Any] = {}
        parser = self.config if not to_flat else self.flattened
        for key, value in parser.items(section):
            new_value: Any = ""
            if is_none(value):
                new_value = None
            elif is_number(value):
                new_value = convert_to_number(value)
                new_value = int(new_value) if is_int(new_value) else new_value
            elif is_bool(value):
                new_value = convert_to_bool(value)
            else:
                new_value = value

            config[key.lower()] = new_value
        return config

    def to_dict(self, to_flat: bool = False) -> Dict[str, Any]:
        """Convert configurations to dictionary.

        :param to_flat: Flag indicating whether to read from
            flattened configurations or normal, defaults to False
        :type to_flat: bool, optional
        :return: Configurations converted to dictionary
        :rtype: Dict[str, Any]
        """
        config: Dict[str, Any] = {}
        if not to_flat:
            for section in self.config.sections():
                config[section.lower()] = self.get(section)
        else:
            if self.flattened is None:
                self.flatten()  # type: ignore
            config = self.get(DEFAULT, True)

        return config
