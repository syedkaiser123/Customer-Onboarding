"""Input configurations processing and handling.

The input configurations can be of following types:
1. cfg/conf
2. yml/yaml
"""
