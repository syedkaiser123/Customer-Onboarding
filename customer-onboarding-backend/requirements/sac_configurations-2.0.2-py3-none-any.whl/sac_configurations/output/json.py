"""Configurations handler to write configurations in json file."""
import json
from typing import Dict

from sac_configurations.constants.chars import FILE_WRITE_STR
from sac_configurations.constants.general import FILE_EXT_JSON
from sac_configurations.constants.messages import INVALID_JSON_FILEPATH
from sac_configurations.exceptions.output import OutputConfigsError
from sac_configurations.output.base import OutputConfig
from sac_configurations.utils.validators import is_valid_filepath


class JsonFile(OutputConfig):
    """JsonFile class to write the configurations to .json file.

    :param OutputConfig: Inherits Base Output configurations
    :type OutputConfig: class
    """

    def __init__(self, path: str) -> None:
        """Initialize JsonFile object.

        :param path: Json file path
        :type path: str
        :raises OutputConfigsError: Output configurations error raised when
            there is some issue while writing configurations to the output media
        """
        super().__init__()
        if not is_valid_filepath(path, FILE_EXT_JSON):
            raise OutputConfigsError(
                self.__class__.__name__, INVALID_JSON_FILEPATH.format(path=path)
            )
        self.path = path

    def write(self, config: Dict) -> int:
        """Write the configurations to the json file at the path provided.

        :param config: Configurations to be written to json file
        :type config: Dict
        :raises OutputConfigsError: Output configurations error raised when
            there is some issue while writing configurations to the output media
        :return: Number of lines written to the json file
        :rtype: int
        """
        count = 0
        file = None
        try:
            # Write the configurations to the json file
            with open(self.path, FILE_WRITE_STR) as file:
                json.dump(config, file)
                count = len(config)
        except Exception as err:
            msg = str(err)
            raise OutputConfigsError(self.__class__.__name__, msg) from err
        return count
