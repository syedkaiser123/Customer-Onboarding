"""Configurations handler to write configurations in OS environment file."""
import os
from typing import Dict

from sac_configurations.constants.chars import EMPTY_STR
from sac_configurations.exceptions.output import OutputConfigsError
from sac_configurations.output.base import OutputConfig


class OsEnv(OutputConfig):
    """OsEnv class to write configurations to the os environment.

    :param OutputConfig: Inherits Base Output configurations
    :type OutputConfig: class
    """

    def __init__(self, path: str = EMPTY_STR) -> None:
        """Initialize OsEnv object.

        :param path: File path, defaults to STRING_EMPTY (Not required here)
        :type path: str, optional
        """
        super().__init__()
        self.path = path

    def write(self, config: Dict) -> int:
        """Write configurations to the os environment.

        :param config: Configurations to be written to os environment
        :type config: Dict
        :raises OutputConfigsError: Output configurations error raised when
            there is some issue while writing configurations to the output media
        :return: Number of lines written to the os environment
        :rtype: int
        """
        count = 0
        try:
            for key, value in config.items():
                if value is not None:
                    os.environ[key] = str(value)
                    count += 1
        except Exception as err:
            msg = str(err)
            raise OutputConfigsError(self.__class__.__name__, msg) from err
        return count
