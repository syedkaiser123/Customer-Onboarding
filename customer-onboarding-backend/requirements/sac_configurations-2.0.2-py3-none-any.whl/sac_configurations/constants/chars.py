"""Character constants."""

EMPTY_STR = ""
SPACE_STR = " "
PERCENT_STR = "%"
COMMA_STR = ","
DOT_STR = "."

# Special characters
NEW_LINE_STR = "\n"

# String representation of None values
NONE_STR = "none"
NULL_STR = "null"

# Verbs
IS_STR = "is"
ARE_STR = "are"

# File modes
FILE_READ_STR = "r"
FILE_WRITE_STR = "w"
FILE_APPEND_STR = "a"
