"""Schema constants."""
# Schema fields
SCHEMA_DTYPE = "dtype"
SCHEMA_REQUIRED = "required"
SCHEMA_DEFAULT = "default"

# Data Types
DTYPE_STRING = "string"
DTYPE_INT = "int"
DTYPE_FLOAT = "float"
DTYPE_BOOL = "bool"
DTYPE_LIST = "list"
DTYPE_DICT = "dict"
DTYPE_SET = "set"
DTYPE_TUPLE = "tuple"
DTYPE_URL = "url"
DTYPE_IP = "ip"
