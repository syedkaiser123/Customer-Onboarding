"""Constans used to manage the configurations."""
