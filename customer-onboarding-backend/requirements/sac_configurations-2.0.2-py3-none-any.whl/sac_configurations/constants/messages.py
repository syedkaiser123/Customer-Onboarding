"""Message constants."""
# Missing configurations messages
MISSING_CONFIGS = "{config} is missing in configurations file."
MISSING_SECTIONS = "Sections {sections} {verb} missing in the configurations."
DATA_TYPE_MISMATCH = (
    "Data Type mismatch in {config}. Required is {required} and found {found}."
)


# Invalid file path messages
INVALID_JSON_FILEPATH = "{path} is not a valid json file path."
INVALID_ENV_FILEPATH = "{path} is not a valid .env file path."
INVALID_FIELD_SCHEMA = (
    "{field} does not exist in {section} in the schema configurations."
)

# Invalid URL or IP address or data type
INVLAID_DATATYPE = "{value} for {field} in the {section} is not valid {dtype}."
