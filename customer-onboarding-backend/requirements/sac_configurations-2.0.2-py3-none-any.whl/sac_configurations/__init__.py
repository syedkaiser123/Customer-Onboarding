"""sac_configurations module to get configurations.

It performs following operations:
1. Read configurations from cfg as well as yaml files
2. Validate all the configurations sections
3. Assign default values
4. Validate all the required configurations.
"""
