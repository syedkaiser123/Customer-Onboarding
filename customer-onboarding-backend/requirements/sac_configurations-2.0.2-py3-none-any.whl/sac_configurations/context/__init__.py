"""Certify the configurations supplied and compare with Schema."""
